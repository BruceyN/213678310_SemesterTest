package service;

import javax.ejb.LocalBean;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.TransactionEntity;


@Stateless
@LocalBean
public class TransactionEJB {

	
	@PersistenceContext
	private EntityManager emp;
	
    public TransactionEJB() {
        // TODO Auto-generated constructor stub
    }

    public void addNew(TransactionEntity transactionEntity)
    {
    	System.out.println("============================");
    	System.out.println(transactionEntity.getName());
    	emp.persist(transactionEntity);
    	System.out.println("============================");
    }
}
