package entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name= "transaction_tbl")
public class TransactionEntity {
	
	@Id_Num
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private Long Id;
    
	private String Name;
	private String SourcePassport;
	private String DestinationPassport;
	private String DestinationBank;
	private String DestationCountry;
	private String AccountNumber;
	private Double Amount; 
	private Long TransactionCode;
	
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	/*===============================================================*/
	public String getSourcePassport() {
		return SourcePassport;
	}
	public void setSourcePassport(String SourcePassport) {
		this.SourcePassport = SourcePassport;
	}
	/*===============================================================*/
	public String getDestinationPassport() {
		return DestinationPassport;
	}
	public void setDestinationPassport(String DestinationPassport) {
		this.DestinationPassport = DestinationPassport;
	}
	/*===============================================================*/
	public String getDestinationBank() {
		return DestinationBank;
	}
	public void setDestinationBank(String DestinationBank) {
		this.DestinationBank = DestinationBank;
	}
	/*===============================================================*/
	public String getDestationCountry() {
		return DestationCountry;
	}
	public void setDestationCountry(String DestationCountry) {
		this.DestationCountry = DestationCountry;
	}
	/*===============================================================*/
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String AccountNumber) {
		this.AccountNumber = AccountNumber;
	}
	/*===============================================================*/
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double Amount) {
		this.Amount = Amount;
	}
	/*===============================================================*/
	public Long getTransactionCode() {
		return TransactionCode;
	}
	public void setTransactionCode(Long TransactionCode) {
		this.TransactionCode = TransactionCode;
	}
	/*===============================================================*/
}
