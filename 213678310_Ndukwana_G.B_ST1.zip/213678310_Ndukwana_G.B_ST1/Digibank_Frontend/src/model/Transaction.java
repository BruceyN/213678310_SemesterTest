package model;

import java.io.Serializable;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import entities.TransactionEntity;

@ManagedBean(name = "transaction")
@SessionScoped
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String Name;
	private String SourcePassport;
	private String DestinationPassport;
	private String DestinationBank;
	private String DestationCountry;
	private String AccountNumber;
	private Double Amount; 
	private Long TransactionCode;
	
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	/*===============================================================*/
	public String getSourcePassport() {
		return SourcePassport;
	}
	public void setSourcePassport(String SourcePassport) {
		this.SourcePassport = SourcePassport;
	}
	/*===============================================================*/
	public String getDestinationPassport() {
		return DestinationPassport;
	}
	public void setDestinationPassport(String DestinationPassport) {
		this.DestinationPassport = DestinationPassport;
	}
	/*===============================================================*/
	public String getDestinationBank() {
		return DestinationBank;
	}
	public void setDestinationBank(String DestinationBank) {
		this.DestinationBank = DestinationBank;
	}
	/*===============================================================*/
	public String getDestationCountry() {
		return DestationCountry;
	}
	public void setDestationCountry(String DestationCountry) {
		this.DestationCountry = DestationCountry;
	}
	/*===============================================================*/
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String AccountNumber) {
		this.AccountNumber = AccountNumber;
	}
	/*===============================================================*/
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double Amount) {
		this.Amount = Amount;
	}
	/*===============================================================*/
	public  Long getTransactionCode() {
		return TransactionCode;
	}
	public void setTransactionCode(Long TransactionCode) {
		this.TransactionCode = TransactionCode;
	}
	/*===============================================================*/
	public TransactionEntity getEntity()
	{
		TransactionEntity transactionEntity = new TransactionEntity();
		transactionEntity.setDestinationPassport(DestinationPassport);
		transactionEntity.setName(Name);
		transactionEntity. setSourcePassport(SourcePassport);
		transactionEntity.setDestinationBank(DestinationBank);
		transactionEntity.setDestationCountry(DestationCountry);
		transactionEntity.setAccountNumber(AccountNumber);
		transactionEntity.setAmount(Amount);
		transactionEntity.setTransactionCode(TransactionCode);
		
		return transactionEntity;
	}
	/*===============================================================*/

}
